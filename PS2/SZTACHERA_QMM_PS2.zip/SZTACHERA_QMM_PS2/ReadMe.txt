1. SZTACHERA_Quantitative_Macroeconomics_PS2.pdf contains the solution of the PS2
2. 1.cd.m Octave file contains the code calculating intial consumption and the time paths of allocations
for exercise 1 c) and d).
3. 2.1.4.py contains the code solving exercise 2 a).
4. 2.1.4.(840).py and 2.1.4.(1540).py generate data for 2 different parametrization for exercise 2 b).